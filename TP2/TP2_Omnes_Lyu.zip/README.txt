Bonjour,

Nous avons fais deux sorties : une artistique et une technique. Vous devez copier les fichiers .qglviewer.xml && ray-tracer.cpp et les coller où il y a tous les autres fichier pour pouvoir voir les différentes sorties.7

Nous avons effectué toutes les parties avec succès. (Jusqu'à la réfraction). De plus, nous avons rajouté les parties suivantes : Plan infini et eau calme.

Cordialement,
Omnes Nathanaël et Lyu Shuyuan
