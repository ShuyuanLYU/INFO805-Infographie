Bonjour,

Voici les questions auxquelles nous avons répondu :

2 - Code initial, application minimale libQGLViewer - FONCTIONNEL.

3 - Soupe de triangles - FONCTIONNEL.

Il y a juste la partie 3.5 qui est partiellement traitée : la couleur ambiante est mal affichée. Mais l'effet multicolore est fonctionnel.

4 - Compression par découpage sur une grille régulière - FONCTIONNEL

Partie 4.4 non fonctionnelle.

Cordialement,

Courage pour la correction !
